var users = require('./db'),
    posts = require('./apiService');

module.exports = {
    apiService:apiService,
    db:db
};