var path = require('path'),
    config;

config = {
    //logic dependent configurations
};

// Export config
module.exports = config;
